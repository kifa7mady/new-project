var express    = require('express');
var taskModel  = require('../models/task');
var router = express.Router();

router.get('/',(req,res)=>{
 res.render('demo');
});

function Paginator(items, page, per_page) {
    var page = page || 1,
    per_page = per_page || 10,
    offset = (page - 1) * per_page,
    paginatedItems = items.slice(offset).slice(0, per_page),
    total_pages = Math.ceil(items.length / per_page);
    return {
        page: page,
        per_page: per_page,
        pre_page: page - 1 ? page - 1 : null,
        next_page: (total_pages > page) ? page + 1 : null,
        total: items.length,
        total_pages: total_pages,
        data: paginatedItems
    };
}

var MyStaticClass = {
    Paginator : function (items, page, per_page) {
        var page = page || 1,
        per_page = per_page || 10,
        offset = (page - 1) * per_page,
        paginatedItems = items.slice(offset).slice(0, per_page),
        total_pages = Math.ceil(items.length / per_page);
        return {
            page: page,
            per_page: per_page,
            pre_page: page - 1 ? page - 1 : null,
            next_page: (total_pages > page) ? page + 1 : null,
            total: items.length,
            total_pages: total_pages,
            data: paginatedItems
        };
    }
}


router.post('/task/getOrderValues',(req,res)=>{
    var fs = require("fs");
    var  path = require("path");
    var ordersPath = path.join(__dirname, '..', 'public', 'json', 'orders.json');
    var ordersObj = JSON.parse(fs.readFileSync(path.resolve(ordersPath)), 'utf8');
    
    var itemsPath = path.join(__dirname, '..', 'public', 'json', 'items.json');
    var itemsObj = JSON.parse(fs.readFileSync(path.resolve(itemsPath)), 'utf8');

    var customersPath = path.join(__dirname, '..', 'public', 'json', 'customers.json');
    var customersObj = JSON.parse(fs.readFileSync(path.resolve(customersPath)), 'utf8');

    ordersObj.forEach(function(order) {
        itemsObj.forEach(function(item) {
            if(order.id === item.orderId){
                order['item_id'] = item.id;
                order['item_name'] = item.name;
                order['item_quantityt'] = item.quantity;
                order['item_basePrice'] = item.basePrice;
            } 
        });
    });

    ordersObj.forEach(function(order) {
        customersObj.forEach(function(customer) {
            if(order.customerId === customer.id){
                order['customer_first_name'] = customer.firstName;
                order['customer_address'] = customer.addresses[0].address;
                order['customer_city'] = customer.addresses[0].city;
                order['customer_zip'] = customer.addresses[0].zip;
                order['customer_email'] = customer.email;
            } 
        });
    });

    var search_value = req.body.search_value;
    var search_type = req.body.search_type;
    var order_by = '';
    var page_number= req.body.page_number ? req.body.page_number : 0;
    var per_page=5;
    var orderdate_value = '';
    var ordersObjNew = [];

    if(search_value && search_type == 'search_by_name'){
        ordersObj.forEach(function(order) {
            if(order['customer_first_name'].toLowerCase().indexOf(search_value.toLowerCase()) >= 0){
                ordersObjNew.push(order);
            }
        });
        ordersObj = ordersObjNew;
    }
    
    if(search_value && search_type == 'search_by_orderid'){
        ordersObj.forEach(function(order) {
            if(order['id'].toLowerCase().indexOf(search_value.toLowerCase()) >= 0){
                ordersObjNew.push(order);
            }
        });
        ordersObj = ordersObjNew;
    }

    

    if(search_type == 'sort_by_order_date'){
        order_by = req.body.order_by;
        if(order_by==='desc'){
            ordersObjNew = ordersObj.sort(custom_sort_date_desc);
        }else if(order_by==='asc'){
            ordersObjNew = ordersObj.sort(custom_sort_date_asc);
        }
        function custom_sort_date_desc(a, b) {
            return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
        }
        function custom_sort_date_asc(a, b) {
            return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime() ;
        }
        ordersObj = ordersObjNew;
    }

    if(search_type == 'sort_by_order_price'){
        order_by = req.body.order_by;
        if(order_by==='desc'){
            ordersObjNew = ordersObj.sort(custom_sort_price_desc);
        }else if(order_by==='asc'){
            ordersObjNew = ordersObj.sort(custom_sort_price_asc);
        }
        function custom_sort_price_desc(a, b) {
            return a.item_basePrice - b.item_basePrice;
        }
        function custom_sort_price_asc(a, b) {
            return b.item_basePrice - a.item_basePrice ;
        }
        ordersObj = ordersObjNew;
    }
    
    if(search_type == 'filter_by_orderdate'){
        orderdate_value = req.body.orderdate_value;
        order_date_value_start = new Date(orderdate_value).setHours(0,0,0,0);
        order_date_value_start = new Date(order_date_value_start);

        order_date_value_end = new Date(orderdate_value).setHours(24,0,0,0);
        order_date_value_end = new Date(order_date_value_end);

        ordersObj.forEach(function(order) {
            if(new Date(order.createdAt) > order_date_value_start && new Date(order.createdAt) < order_date_value_end){
                ordersObjNew.push(order);
            }
        });
        ordersObj = ordersObjNew;
    }

    if(search_value && search_type == 'search_by_order_item_price'){
        ordersObj.forEach(function(order) {
            test = order.item_basePrice;
            if(order.item_basePrice.toString().toLowerCase().indexOf(search_value.toString().toLowerCase()) >= 0){
                ordersObjNew.push(order);
            }
        });
        ordersObj = ordersObjNew;
    }
    pagination = MyStaticClass.Paginator(ordersObj,page_number,per_page);

    res.json({msg:'success',data:ordersObj,pagination:pagination,page_number:page_number});
});

module.exports = router;