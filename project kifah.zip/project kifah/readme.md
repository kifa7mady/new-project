Install Packages

-- npm install

Start Application

-- node app.js