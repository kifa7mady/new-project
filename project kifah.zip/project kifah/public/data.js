$(document).ready(function(){

    getOrderValues();

    function getOrderValues(page_number = 1){
        $.ajax({
            url:'/task/getOrderValues',
            method:'post',
            dataType:'json',
            success:function(response){
                var orders = response.pagination.data;
                $.each(orders, function(i, orders) {
                    $('.table-container').append("<div class='body-content flex-row-100'>"
                    + "<div class='col-item flex-row'>" + orders.id +"</div>"
                    + "<div class='col-item flex-row'>" + orders.createdAt +"</div>"
                    + "<div class='col-item flex-row'>" + orders.item_id +"</div>"
                    + "<div class='col-item flex-row'>" + orders.item_name +"</div>"
                    + "<div class='col-item flex-row'>" + orders.item_quantityt +"</div>"
                    + "<div class='col-item flex-row'>" + orders.item_basePrice +"</div>"
                    + "<div class='col-item flex-row'>" + orders.customer_first_name +"</div>"
                    + "<div class='col-item flex-row'>" + orders.customer_address +"</div>"
                    + "<div class='col-item flex-row'>" + orders.customer_city +"</div>"
                    + "<div class='col-item flex-row'>" + orders.customer_zip +"</div>"
                    + "<div class='col-item flex-row'>" + orders.customer_email +"</div>"
                    + "</div>"); 
                });

                for(i=1;i<=response.pagination.total_pages;i++){
                    var active = page_number === i ? "active" : "";
                    $('.paginator').append("<a class='paginator-item " + active + "' data-page_number=" + i +">" + i +"</div>");
                }
            },
            error:function(response){
                alert('server error');
            }
        });
    }
    

    $(document).on("click",".paginator-item",function() {
        $.each($('.body-content'), function(i,_this) {
            _this.remove();
        });
        var page_number = $(this).attr('data-page_number');
        var search_type = $('.paginator').attr('data-search_type');
        var order_by =  $('.paginator').attr('data-order_by');
        var search_value = $('.paginator').attr('data-search_value');
        var orderdate_value = $('.paginator').attr('data-orderdate_value');
        var _this =  $(this);
        setTimeout(function () {
            $.ajax({
                url:'/task/getOrderValues',
                method:'post',
                dataType:'json',
                data:{
                    'page_number':page_number,
                    'search_type':search_type,
                    'search_value':search_value,
                    'order_by':order_by,
                    'orderdate_value':orderdate_value
                },
                success:function(response){
                    $('.icon-item').attr('data-active',0);
                    var orders = response.pagination.data;
                    $.each(orders, function(i, orders) {
                        $('.table-container').append("<div class='body-content flex-row-100'>"
                        + "<div class='col-item flex-row'>" + orders.id +"</div>"
                        + "<div class='col-item flex-row'>" + orders.createdAt +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_id +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_name +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_quantityt +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_basePrice +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_first_name +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_address +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_city +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_zip +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_email +"</div>"
                        + "</div>"); 
                    });
                    $('.paginator-item').removeClass('active');
                    _this.addClass('active');
                },
                error:function(response){
                    alert('server error');
                }
            });
        }, 100);
    });

    var timeoutID = null;
    $('#search_query_by_name').keyup(function(e) {
        $.each($('.body-content'), function(i,_this) {
            _this.remove();
        });
        clearTimeout(timeoutID);
        var search_value = e.target.value;
        timeoutID = setTimeout(function () {
            $.ajax({
                url:'/task/getOrderValues',
                method:'post',
                dataType:'json',
                data:{
                    'search_value':search_value,
                    'search_type':'search_by_name'
                },
                success:function(response){
                    console.log(response);
                    var orders = response.pagination.data;
                    $.each(orders, function(i, orders) {
                        $('.table-container').append("<div class='body-content flex-row-100'>"
                        + "<div class='col-item flex-row'>" + orders.id +"</div>"
                        + "<div class='col-item flex-row'>" + orders.createdAt +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_id +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_name +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_quantityt +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_basePrice +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_first_name +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_address +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_city +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_zip +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_email +"</div>"
                        + "</div>"); 
                    });
                    $('.paginator').html('');
                    $('.paginator').attr('data-search_type','search_by_name');
                    $('.paginator').attr('data-search_value',search_value);
                    for(i=1;i<=response.pagination.total_pages;i++){
                        var active = i === 1 ? "active" : "";
                        $('.paginator ').append("<a class='paginator-item " + active + "' data-page_number=" + i +">" + i +"</div>");
                    }
                },
                error:function(response){
                    alert('server error');
                }
            });
        }, 100);
    });

    $('#search_query_by_orderid').keyup(function(e) {
        $.each($('.body-content'), function(i,_this) {
            _this.remove();
        });
        clearTimeout(timeoutID);
        var search_value = e.target.value;
        timeoutID = setTimeout(function () {
            $.ajax({
                url:'/task/getOrderValues',
                method:'post',
                dataType:'json',
                data:{
                    'search_value':search_value,
                    'search_type':'search_by_orderid'
                },
                success:function(response){
                    console.log(response);
                    var orders = response.pagination.data;
                    $.each(orders, function(i, orders) {
                        $('.table-container').append("<div class='body-content flex-row-100'>"
                        + "<div class='col-item flex-row'>" + orders.id +"</div>"
                        + "<div class='col-item flex-row'>" + orders.createdAt +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_id +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_name +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_quantityt +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_basePrice +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_first_name +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_address +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_city +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_zip +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_email +"</div>"
                        + "</div>"); 
                    });

                    $('.paginator').html('');
                    $('.paginator').attr('data-search_type','search_by_orderid');
                    $('.paginator').attr('data-search_value',search_value);
                    for(i=1;i<=response.pagination.total_pages;i++){
                        var active = i === 1 ? "active" : "";
                        $('.paginator').append("<a class='paginator-item " + active + "' data-page_number=" + i +">" + i +"</div>");
                    }
                },
                error:function(response){
                    alert('server error');
                }
            });
        }, 100);
    }); 
    
    
    $('#sort_by_order_date').click(function(e) {
        $.each($('.body-content'), function(i,_this) {
            _this.remove();
        });
        var _this =  $(this);
        var order_by = _this.attr('data-sort');
        setTimeout(function () {
            $.ajax({
                url:'/task/getOrderValues',
                method:'post',
                dataType:'json',
                data:{
                    'search_type':'sort_by_order_date',
                    'order_by':order_by
                },
                success:function(response){
                    if(_this.attr('data-sort')=='asc'){
                        _this.attr('data-sort','desc');
                    }else if(_this.attr('data-sort')=='desc'){
                        _this.attr('data-sort','asc');
                    }
                    $('.icon-item').attr('data-active',0);
                    _this.attr('data-active',1);
                    var orders = response.pagination.data;
                    $.each(orders, function(i, orders) {
                        $('.table-container').append("<div class='body-content flex-row-100'>"
                        + "<div class='col-item flex-row'>" + orders.id + "</div>"
                        + "<div class='col-item flex-row'>" + orders.createdAt +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_id +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_name +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_quantityt +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_basePrice +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_first_name +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_address +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_city +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_zip +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_email +"</div>"
                        + "</div>"); 
                    });

                    $('.paginator').html('');
                    $('.paginator').attr('data-search_type','sort_by_order_date');
                    for(i=1;i<=response.pagination.total_pages;i++){
                        var active = i === 1 ? "active" : "";
                        $('.paginator').append("<a class='paginator-item " + active + "' data-page_number=" + i +">" + i +"</div>");
                    }
                },
                error:function(response){
                    alert('server error');
                }
            });
        }, 100);
    });

    $('#sort_by_order_price').click(function(e) {
        $.each($('.body-content'), function(i,_this) {
            _this.remove();
        });
        var _this =  $(this);
        var order_by = _this.attr('data-sort');
        setTimeout(function () {
            $.ajax({
                url:'/task/getOrderValues',
                method:'post',
                dataType:'json',
                data:{
                    'search_type':'sort_by_order_price',
                    'order_by':order_by
                },
                success:function(response){
                    if(_this.attr('data-sort')=='asc'){
                        _this.attr('data-sort','desc');
                    }else if(_this.attr('data-sort')=='desc'){
                        _this.attr('data-sort','asc');
                    }
                    $('.icon-item').attr('data-active',0);
                    _this.attr('data-active',1);
                    var orders = response.pagination.data;
                    $.each(orders, function(i, orders) {
                        $('.table-container').append("<div class='body-content flex-row-100'>"
                        + "<div class='col-item flex-row'>" + orders.id +"</div>"
                        + "<div class='col-item flex-row'>" + orders.createdAt +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_id +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_name +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_quantityt +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_basePrice +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_first_name +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_address +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_city +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_zip +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_email +"</div>"
                        + "</div>"); 
                    });
                    $('.paginator').html('');
                    $('.paginator').attr('data-search_type','sort_by_order_price');
                    $('.paginator').attr('data-order_by',order_by);
                    for(i=1;i<=response.pagination.total_pages;i++){
                        var active = i === 1 ? "active" : "";
                        $('.paginator').append("<a class='paginator-item " + active + "' data-page_number=" + i +">" + i +"</div>");
                    }
                },
                error:function(response){
                    alert('server error');
                }
            });
        }, 100);
    });

    $('#filter_button_by_orderdate').click(function(e) {
        $.each($('.body-content'), function(i,_this) {
            _this.remove();
        });
        var _this =  $(this);
        var orderdate_value = $('#orderdate_value').val();
        setTimeout(function () {
            $.ajax({
                url:'/task/getOrderValues',
                method:'post',
                dataType:'json',
                data:{
                    'search_type':'filter_by_orderdate',
                    'orderdate_value':orderdate_value
                },
                success:function(response){
                   
                    $('.icon-item').attr('data-active',0);
                    var orders = response.pagination.data;
                    $.each(orders, function(i, orders) {
                        $('.table-container').append("<div class='body-content flex-row-100'>"
                        + "<div class='col-item flex-row'>" + orders.id +"</div>"
                        + "<div class='col-item flex-row'>" + orders.createdAt +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_id +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_name +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_quantityt +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_basePrice +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_first_name +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_address +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_city +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_zip +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_email +"</div>"
                        + "</div>"); 
                    });
                    $('.paginator').html('');
                    $('.paginator').attr('data-search_type','filter_by_orderdate');
                    $('.paginator').attr('data-orderdate_value',orderdate_value);
                    for(i=1;i<=response.pagination.total_pages;i++){
                        var active = i === 1 ? "active" : "";
                        $('.paginator').append("<a class='paginator-item " + active + "' data-page_number=" + i +">" + i +"</div>");
                    }
                },
                error:function(response){
                    alert('server error');
                }
            });
        }, 100);
    });

    $('#search_query_by_order_item_price').keyup(function(e) {
        $.each($('.body-content'), function(i,_this) {
            _this.remove();
        });
        clearTimeout(timeoutID);
        var search_value = e.target.value;
        timeoutID = setTimeout(function () {
            $.ajax({
                url:'/task/getOrderValues',
                method:'post',
                dataType:'json',
                data:{
                    'search_value':search_value,
                    'search_type':'search_by_order_item_price'
                },
                success:function(response){
                    console.log(response);
                    var orders = response.pagination.data;
                    $.each(orders, function(i, orders) {
                        $('.table-container').append("<div class='body-content flex-row-100'>"
                        + "<div class='col-item flex-row'>" + orders.id +"</div>"
                        + "<div class='col-item flex-row'>" + orders.createdAt +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_id +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_name +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_quantityt +"</div>"
                        + "<div class='col-item flex-row'>" + orders.item_basePrice +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_first_name +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_address +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_city +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_zip +"</div>"
                        + "<div class='col-item flex-row'>" + orders.customer_email +"</div>"
                        + "</div>"); 
                    });
                    $('.paginator').html('');
                    $('.paginator').attr('data-search_type','search_by_order_item_price');
                    $('.paginator').attr('data-search_value',search_value);
                    for(i=1;i<=response.pagination.total_pages;i++){
                        var active = i === 1 ? "active" : "";
                        $('.paginator').append("<a class='paginator-item " + active + "' data-page_number=" + i +">" + i +"</div>");
                    }
                },
                error:function(response){
                    alert('server error');
                }
            });
        }, 100);
    }); 


});